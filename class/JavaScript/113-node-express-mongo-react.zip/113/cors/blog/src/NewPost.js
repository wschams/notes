import React, { Component } from 'react';

export default class NewPost extends Component {
    render() {
        return (
            <div>New Post works!</div>
        );
    }
}